package com.example.omar_salem.mvvm_architectural_pattern.util

/**
 * TODO: Add class header
 */
object ApiUtils {
    val API_KEY="254ef4875714b785ce16c48c8c873b49"
    val BASE_URL = "http://api.themoviedb.org/3/"
    val BASE_IMAGE_URL = "http://image.tmdb.org/t/p/w185/"
    val BASE_IMAGE_URL_BANNER = "http://image.tmdb.org/t/p/w650/"
}